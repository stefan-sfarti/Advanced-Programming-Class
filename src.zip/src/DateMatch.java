public interface DateMatch {
    boolean match(String date);
}
