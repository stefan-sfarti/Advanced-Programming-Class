import java.util.Map;

public class CEO extends Person{
    int noOfLambos;
    public CEO(String name, String birthDate, Map<Node, String> relationships, int lambos) {
        super(name, birthDate, relationships);
        this.noOfLambos = lambos;
    }
}
