import java.util.HashSet;
import java.util.Set;

public class Company implements Node, Comparable<Company>{
    private String name;
    private static Set<String> names = new HashSet<>();
    public String getName() {
        return name;
    }

    public Company(String name) {
        if (names.contains(name)) {
            throw new IllegalArgumentException("Name already exists: " + name);
        }
        names.add(name);
        this.name = name;
    }

    @Override
    public int compareTo(Company c) {
        return this.name.compareTo(c.getName());
    }
}
