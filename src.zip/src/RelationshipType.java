public enum RelationshipType {
    FRIENDS,
    RELATIONSHIP,
    BOSS,
    EMPLOYEE,
    ACQUAINTACES


}
