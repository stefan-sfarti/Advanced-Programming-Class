import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Main {
    public static void main(String args[]) {

        Person p1 = new Person("Stefan", "11-10-1999");
        Person p2 = new Person("Carina", "01-03-2002");
        Company c1 = new Company("Amazon");
        Company c2 = new Company("Alten");
        p1.addRelationship(p2, "iubi");
        List<Node> nodes = new ArrayList<>();
        nodes.add(p1);
        nodes.add(p2);
        nodes.add(c1);
        nodes.add(c2);
        System.out.println(p1.getRelationships());
        for (Node node: nodes) {
            System.out.println(node.getName());
            if (node instanceof Person){
                System.out.println(((Person) node).getBirthDate());
            }
        }
    }
}
