import java.util.Map;

public class Designer extends Person{
    int noOfFashionShows;
    public Designer(String name, String birthDate, Map<Node, String> relationships, int fashionShows) {
        super(name, birthDate, relationships);
        this.noOfFashionShows = fashionShows;
    }
}
