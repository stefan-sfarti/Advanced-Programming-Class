import java.util.Map;

public interface Node {
    String getName();

    public Map<Node, String> getRelationships();

}
