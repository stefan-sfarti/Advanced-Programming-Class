public interface Node {
    String getName();

}
