import java.util.Map;

public class Programmer extends Person{
    private String favouriteLanguage;
    public Programmer(String name, String birthDate, Map<Node, String> relationships, String favouriteLanguage) {
        super(name, birthDate, relationships);
        this.favouriteLanguage = favouriteLanguage;
    }

    public String getFavouriteLanguage() {
        return favouriteLanguage;
    }



    public void setFavouriteLanguage(String favouriteLanguage) {
        this.favouriteLanguage = favouriteLanguage;
    }
}
