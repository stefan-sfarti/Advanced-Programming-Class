import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Network {
    private List<Node> nodes = new ArrayList<>();
    public List<Node> getNodes() {
        return nodes;
    }
    public void addNode(Node node) {
        nodes.add(node);
    }

    public void sortNodesByImportance() {
        nodes.sort((n1, n2) -> n2.getRelationships().size() - n1.getRelationships().size());
    }
    public void printNetwork() {
        for (Node node : nodes) {
            if (node instanceof Person){
                System.out.println(node.getName());
            }else System.out.println(node.getName());

        }
    }

    @Override
    public String toString() {
        return "Network{" +
                "nodes=" + nodes +
                '}';
    }
}
