import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Network implements Comparable<Node> {
    private List<Node> nodes = new ArrayList<>();



    public List<Node> getNodes() {
        return nodes;
    }

    public void setNodes(List<Node> nodes) {
        this.nodes = nodes;
    }


    public void addNode(Node node) {
        nodes.add(node);
    }

    @Override
    public int compareTo(Node node) {
        return 0;
    }

    @Override
    public String toString() {
        return "Network{" +
                "nodes=" + nodes +
                '}';
    }
}
